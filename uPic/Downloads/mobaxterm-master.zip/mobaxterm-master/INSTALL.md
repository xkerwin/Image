### [MobaXterm](https://mobaxterm.mobatek.net)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/mobaxterm/archive/master.zip) option

Open your local `MobaXterm.ini` file (normally at `Documents/MobaXterm/MobaXterm.ini`), and replace the `[Colors]` section with the contents of the `MobaXterm.ini` file you downloaded.

This will change the default color scheme - saved sessions will need to be recreated for it to take effect.