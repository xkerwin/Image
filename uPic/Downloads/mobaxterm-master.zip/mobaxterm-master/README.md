# Dracula for [MobaXterm](https://mobaxterm.mobatek.net)

> A dark theme for [MobaXterm](https://mobaxterm.mobatek.net).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/mobaxterm](https://draculatheme.com/mobaxterm).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/mobaxterm/graphs/contributors).

[![Phuurl](https://avatars2.githubusercontent.com/u/1835431?s=70&v=4)](https://github.com/Phuurl) |
--- |
[Phuurl](https://github.com/Phuurl) |

## License

[MIT License](./LICENSE)
